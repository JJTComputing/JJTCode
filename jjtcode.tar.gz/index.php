<?php
error_reporting(-1);
// Start the session!
session_start();

// Load up all the function requires
require("sources/jjtsql.php");
require("sources/sql.php");
require("sources/functions.php");

// If the person is not logged in, they are a guest and so we give them a user id of 1
if (!login_check())
{
	$_SESSION['user_id']=0;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>JJTCode</title>

<!-- CSS -->
<link href="style/css/transdmin.css" rel="stylesheet" type="text/css" media="screen" />
<!--[if IE 6]><link rel="stylesheet" type="text/css" media="screen" href="style/css/ie6.css" /><![endif]-->
<!--[if IE 7]><link rel="stylesheet" type="text/css" media="screen" href="style/css/ie7.css" /><![endif]-->

<!-- JavaScripts-->
<script type="text/javascript" src="style/js/jquery.js"></script>
<script type="text/javascript" src="style/js/jNice.js"></script>
</head>

<body>
	<div id="wrapper">
    	<!-- h1 tag stays for the logo, you can use the a tag for linking the index page -->
    	
        
        <!-- You can name the links with lowercase, they will be transformed to uppercase by CSS, we prefered to name them with uppercase to have the same effect with disabled stylesheet -->
        <ul id="mainNav">
        	<li><a href="/" class="active"><img src="/icon/go-home.png" />&nbsp; HOME</a></li> <!-- Use the "active" class for the active menu item  -->
        	<li><a href="/?action=project_view"><img src="/icon/projects.png" />&nbsp; PROJECTS</a></li> 
			<li><a href="/?action=user_view"><img src="/icon/users.png" />&nbsp;USERS</a></li>
			<li><a href="/?action=faq"><img src="/icon/faq.png" />&nbsp;FAQ</a></li>
        	<li class="logout"><a href=<?php echo (login_check() ? '"/logout.php">LOGOUT</a><img src="/icon/logout.png" />' : '"/?action=login">LOGIN</a><img src="/icon/login.png" />'); ?>
        	</li>
        </ul>
        <!-- // #end mainNav -->
        
        <div id="containerHolder">
			<div id="container">
        		  
                <!-- // #sidebar -->
                
                <!-- h2 stays for breadcrumbs 
                <h2><a href="/">Dashboard</a> &raquo; 
				<a href="#" class="active">Print resources</a></h2> -->
                
                <div id="main">
				<br />
                	<?php
					// Lets see what they want to do
					if (isset($_REQUEST['action']))
					{
						// Validation
						$action=trim($_REQUEST['action']);
						$action=preg_replace("/[^a-z_]/", "", $action);
						// End Validation
			
						// Check to see whether the requested file exists!
						if (file_exists("actions/".$action.".php"))
						{
							// If they want to do something, lets do it!
							require('actions/'.$action.'.php');
						}
						// But if the file doesn't exist, tell the user!
						else
						{
							echo '<h3>The Requested Action Does not Exist!</h3>';
						}
					}
					
					// But there is nothing to do, load the home page!
					else
					{
						require("actions/index.php");
					}
					
					?>
					<br />
                </div>
                <!-- // #main -->
                
                <div class="clear"></div>
            </div>
            <!-- // #container -->
        </div>	
        <!-- // #containerHolder -->
        
        <p id="footer">JJTComputing, unless mentioned, does not create, endorse, or control the code that is on the website. Use at your own risk!</p>
    </div>
    <!-- // #wrapper -->
</body>
</html>
