editAreaLoader.init({
		id : "textarea"		// textarea id
		,start_highlight: true		// to display with highlight mode on start-up
		,width:900
	});
