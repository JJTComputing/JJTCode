<?php
if (!jjtcms_login_check() || !defined("cms"))
{
	die("Hacking Attempt!");
}

// Have a look whether they've uploaded the file
if (!isset($_FILES['textfile']))
{
	?>
	<h1>Upload Text File</h1>
    <form enctype="multipart/form-data" action="admin.php" method="POST" id="form" name="post">
    <input type="hidden" name="MAX_FILE_SIZE" value="1000000">
    <label>Text File:</label> <input name="textfile" type="file"> <br />
	<label>Post Title:</label> <input type="text" name="title"  onChange="url_generate();"/><br />
	<label>URL:</label> <input type="text" name="url" /><br />
	<input type="hidden" name="action" value="textfile">
    
    <select name="category">
    <?php
	
	// Show the categories

    $category=jjtsql_table_field_array_load("category");

    foreach ($category as $value)
    {
        echo '<option value="'.$value['link'].'">'.$value['name'].'</option>';
    }
    ?>
	</select>
	<br /><br />
	<input type="submit" value="Send File">
	</form>
	
<?php
}
// Check whether there has been an error
elseif ($_FILES['textfile']['error'] > 0)
{ // There's been an error, lets have a look at what it is
	 echo 'Problem: ';
    switch ($_FILES['textfile']['error'])
    {
      case 1:	echo 'File exceeded upload_max_filesize';
	  			break;
      case 2:	echo 'File exceeded max_file_size';
	  			break;
      case 3:	echo 'File only partially uploaded';
	  			break;
      case 4:	echo 'No file uploaded';
	  			break;
	  case 6:   echo 'Cannot upload file: No temp directory specified.';
	  			break;
	  case 7:   echo 'Upload failed: Cannot write to disk.';
	  			break;
    }
}
// But if it has been, lets do the work!
else
{
	 //Firstly, we need to open it
	$file=fopen($_FILES['textfile']['tmp_name'], "r");
	$info=mime_content_type($_FILES['textfile']['tmp_name']);
	
	if ($info!="text/plain")
	{
		die("File is not a plain text file");
	}
	
	// Load up the content array and then we'll use the makepost.php file to do the rest
	// Simulate POST variables
	$_POST['post']=fread($file, filesize($_FILES['textfile']['tmp_name']));
	require("post/makepost.php");
	
}
