<?php
// Lets see what the user wants to do
if ($_REQUEST['do']=="create")
{
	// Check to see whether the user is allowed to create projects
	if ($_SESSION['level']<=2)
	{
		echo '<h3>You are not allowed to create projects!</h3>';
	}
	
	else
	{
		// Validate the data and generate the variables
		$project=preg_replace("[^0-9a-zA-Z]", "", addslashes($_POST['project_name']));
		$link=preg_replace("[^0-9a-zA-Z]", "", trim(addslashes($_POST['project_name'])));
		$description=$_POST['description'];
		$level=preg_replace("[^0-3]", "", $_POST['level']);
		$visible=preg_replace("[^0-1]", "", $_POST['visible']);
		
		// Check to see whether level or visible are empty, if they are, set a default
		if (empty($level))
		{
			$level = 1;
		}
		
		if (empty($visible))
		{
			$visible = 1;
		}
		
		// End variable validation
	
		// Now we check to see whether the project name already exists
		$query="SELECT * FROM projects WHERE project_name = '$project'";
		$result=mysql_query($query);
		
		if (mysql_num_rows($result)>0)
		{
			echo '<p>The project name already exists!</p>';
		}
		
		// End validation, if everything is fine, go ahead an insert!
		else
		{
			// Create the project in the database
			$query="INSERT INTO projects VALUES ('$project', '$link', '$description', '$time', '$time', '$level', '$visible', NULL)";
			mysql_query($query);
	
			// Give the user administrative rights to the project
			// Firstly, we need to get the project id
			$query="SELECT * FROM projects WHERE project_name = '$project'";
			$result=mysql_query($query);
			$project_id = mysql_result($result, 0, "id");
	
			// Now we insert the data into the project_users table to give the permissions
			$query="INSERT INTO project_users VALUES ('$_SESSION[user_id]', '$project_id', '4')";
			mysql_query($query);
	
			// Redirect the user to the project page
			?>
			<script language="javascript" type="text/javascript">
			window.location = "/?action=project_view&project_id=<?php echo $project_id; ?>";
			</script>
			<?php
		}
	}	
}
?>
	
	
	
	
