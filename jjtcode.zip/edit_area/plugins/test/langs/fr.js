editArea.add_lang("fr",{
test_select:"choix balise",
test_but: "bouton de test"
});
