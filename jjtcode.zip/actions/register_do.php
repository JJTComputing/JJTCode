<?php
// Here we register the user into the MySQL database

// Perform some validation
$error="";
// Make sure there aren't any empty values
if (empty($_POST['pass1']) || empty($_POST['pass2']))
{
	$error.="The password field is empty! ";
}

if (empty($_POST['username']))
{
	$error.="The username is empty! ";
}

if (empty($_POST['login']))
{
	$error.="The login name is empty! ";
}

if (empty($_POST['email']))
{
	$error.="The email field is empty! ";
}

// If the error variable is not empty, then there is no point continuing, as it would be a waste of resources
if (!empty($error))
{
	echo '<p class="warning">'.$error.'</p>';
}
// But if the error variable is empty, then lets do some proper validation!
else
{
	// Check the username for invalid characters
	if (preg_match("[^0-9a-zA-Z]", $_POST['username']))
	{
		$error.="The username contains invalid characters! ";
	}
	
	if (preg_match("[^0-9a-zA-Z]", $_POST['login']))
	{
		$error.="The login contains invalid characters! ";
	}
	
	if (!check_email_address($_POST['email']))
	{
		$error.="The email address is invalid ";
	}
	
	// Make sure the passwords are the same
	if ($_POST['pass1']!=$_POST['pass2'])
	{
		$error.="The Entered Passwords Do Not Match! ";
	}
	
	if (!empty($error))
	{
		echo '<p class="warning">'.$error.'</p>';
	}
	
	else
	{
		// Now we check whether the login exists in the MySQL database
		$query="SELECT * FROM users WHERE login = '$_POST[login]'";
		$result=mysql_query($query);
		
		// If the row count is above 0 then there are matches, and the login is already in use!
		if (mysql_num_rows($result)>0)
		{
			$error.="The login already exists. ";
		}
		
		// Now do the same for the username!
		$query="SELECT * FROM users WHERE username = '$_POST[username]'";
		$result=mysql_query($query);
		
		// Again, if the row count is above 0, we have matches!
		if (mysql_num_rows($result)>0)
		{
			$error.="The username already exists!";
		}
		
		if (!empty($error))
		{
			echo '<p class="warning">'.$error.'</p>';
		}
		
		// But if the username/login is unique, lets finally go ahead and register them!
		else
		{
			// Encrypt the password!
			$password = md5($_POST['pass1']);
	
			$query="INSERT INTO users VALUES ('$_POST[login]', '$_POST[username]', '$password', '$_POST[email]', '1', NULL)";
			$result=mysql_query($query);
		
			// Generate a random number to turn into a MD5 hash so we can validate the user's email address
			$num=rand();
			$code=md5($num.$_POST['login']);
			
			// Insert it into the MySQL database to remember it!
			$query="INSERT INTO user_validation VALUES ('$_POST[login]', '$code')";
			mysql_query($query);
			
			// Send the user an email to see whether their address is valid with the code
			mail($_POST['email'], "
			JJTCode Registration", "Hello, and welcome to JJTCode! You now need to confirm your email address. Please copy and
			paste this link to confirm this: http://code.jjtcomputing.co.uk/?action=validate&code=".$code
			, "From: webmaster@jjtcomputing.co.uk");
			
			echo '<p>Thank you for registering at JJTCode. Until you validate your email address, you will not have the 
			full privledges of a user.</p>';
		}
	}
}
