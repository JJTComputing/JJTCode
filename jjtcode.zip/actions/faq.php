<h2>FAQ</h2>
<h3>What is this JJTCode?</h3>
<p>JJTCode is a code repository, like <a href="http://docs.google.com">Google Docs,</a> but for code. It allows you
to develop your application anywhere, on any computer with an internet connection and an internet browser, without having to
use an IDE, while still having syntax highlighting.</p>
<h3>How do I Use It?</h3>
<p>To use JJTCode, firstly you need to <a href="/?action=register">register.</a> Once you have confirmed your email address,
you will have an option on the <a href="/?action=project_view">projects</a> page to create a project.</p>
<h3>I've Found a Bug!</h3>
<p>Please can you <a href="mailto:webmaster@jjtcomputing.co.uk?subject=JJTCode Bug">email us</a>, saying what the bug is, whether it is a consistant bug (i.e. it happens everytime you do something,
or just at certain intervals), what you have to do to get the bug to happen, and any other information you think is 
relavent.</p>
