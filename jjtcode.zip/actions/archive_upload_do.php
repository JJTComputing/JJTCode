<?php
$zip = zip_open($_FILES['zip']['tmp_name']);


if ($zip)
  {
  while ($zip_entry = zip_read($zip))
    {
    echo "<p>";
    echo "Name: " . zip_entry_name($zip_entry) . "<br />";
    if (zip_entry_open($zip, $zip_entry))
      {
      // some code
      }
    echo "</p>";
  }
zip_close($zip);
}
?>
